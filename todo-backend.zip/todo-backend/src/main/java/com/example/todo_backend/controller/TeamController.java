package com.example.todo_backend.controller;


import com.example.todo_backend.model.CreateTeam;
import com.example.todo_backend.model.TeamModel;

import com.example.todo_backend.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/team")
public class TeamController {

    @Autowired
    private TeamService team;



    @GetMapping
    public ResponseEntity<List<TeamModel>> getAllTeam(){
        return new ResponseEntity<>(team.getAllTeams(), HttpStatus.OK);
    }


    @PostMapping
    public TeamModel createTeam(  @RequestBody CreateTeam createteam){
        return (TeamModel) team.createTeam(createteam);
    }
}
