package com.example.todo_backend.model;

public enum Role {

        ADMIN,
        LEADER,
        MEMBERS

}
