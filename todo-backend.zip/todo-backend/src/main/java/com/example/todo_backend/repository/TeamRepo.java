package com.example.todo_backend.repository;

import com.example.todo_backend.model.TeamModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepo extends JpaRepository<TeamModel,Long> {
}
