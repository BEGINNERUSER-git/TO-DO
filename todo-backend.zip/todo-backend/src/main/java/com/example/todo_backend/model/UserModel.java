package com.example.todo_backend.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


import java.util.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserModel implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String Name;
    private String Designation;

    @Column(unique = true,nullable = false,length =25 )
    private String userName;

    @Column(nullable = false,length =10 )
    private String Password;

    @Enumerated(EnumType.STRING )
    private Set<Role> role=new HashSet<>();


    @JsonIgnore
    @ManyToMany(mappedBy = "members")
    private Set<TeamModel> teams=new HashSet<>();



    public Collection<? extends GrantedAuthority> getAuthorities() {
         return List.of(()->"USER");
    }

    @Override
    public String getUsername() {
        return userName;
    }




}
