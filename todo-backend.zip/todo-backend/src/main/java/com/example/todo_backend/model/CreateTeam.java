package com.example.todo_backend.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateTeam {


  private  String teamName;
  private String teamDescription;
  private LocalDateTime dueDate;
  private Set<Integer> membersIds;



}
