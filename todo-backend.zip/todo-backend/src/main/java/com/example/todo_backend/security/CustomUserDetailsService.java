package com.example.todo_backend.security;

import com.example.todo_backend.model.UserModel;
import com.example.todo_backend.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

//Replace in-memory authentication with real user authentication backed by your UserRepo and UserModel.
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserModel user=userRepo.findByUserName(username).orElseThrow(()-> new UsernameNotFoundException("User not found with username: " + username));

        Set<GrantedAuthority> authorities=user.getRole().stream().map(role -> new SimpleGrantedAuthority("ROLE_" + role.name()))
                .collect(Collectors.toSet());

        return new User(user.getUsername(),user.getPassword(),authorities);
    }
}
