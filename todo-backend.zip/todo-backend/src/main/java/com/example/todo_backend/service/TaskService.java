package com.example.todo_backend.service;

import java.util.List;

import com.example.todo_backend.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import com.example.todo_backend.model.TaskModel;
import com.example.todo_backend.model.TaskModel.TaskStatus;
import com.example.todo_backend.model.UserModel;
import com.example.todo_backend.repository.Taskrepo;
import org.springframework.web.bind.annotation.ControllerAdvice;


@ControllerAdvice
@Service
public class TaskService {
   
    @Autowired
    private Taskrepo task;
    

    @Autowired
   private UserService userService;


    public List<TaskModel> getAllTasks(){
        return task.findAll();
    }
    // public List<TaskModel>getByStatus() 

    public List<TaskModel> getTaskByStatus(TaskStatus taskStatus) {
        return task.findByStatus(taskStatus);
    }

    public List<TaskModel> getTasksByUser(UserModel user) {
        if (user.getRole().contains(Role.MEMBERS)) {
            // Members: see tasks assigned to or created by them
            List<TaskModel> owned = task.findByOwner(user);
            List<TaskModel> assigned = task.findByAssignee(user);
            owned.addAll(assigned); // merge both lists
            return owned;
        } else if (user.getRole().contains(Role.LEADER)) {
            // Leaders: see tasks they created (owner)
            return task.findByOwner(user);
        } else if (user.getRole().contains(Role.ADMIN)) {
            // Admins: see everything
            return task.findAll();
        } else {
            throw new AccessDeniedException("Role not recognized.");
        }
    }

    public TaskModel addTask(TaskModel tasked){
       return task.save(tasked);
        
    }

    public TaskModel addTaskForUser(TaskModel tasked, UserModel user) {
      if(user.getRole().contains(Role.MEMBERS)){
          tasked.setOwner(user);
          tasked.setAssignee(user);
      } else if (user.getRole().contains(Role.LEADER)) {
          if (tasked.getAssignee()==null){
              tasked.setAssignee(user);
          }
          tasked.setOwner(user);
      }
        return task.save(tasked);
    }

    public TaskModel updateTask(Long id, TaskModel updateData, UserModel currentUser) {
        TaskModel tasks = task.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        // Members and Leaders can only update their own tasks
        if (!tasks.getOwner().equals(currentUser)) {
            throw new AccessDeniedException("You can only modify your own tasks.");
        }

        tasks.setTitle(updateData.getTitle());
        tasks.setStatus(updateData.getStatus());
        return task.save(tasks);
    }


    public void toBeDeleted(Long id){
        
         task.deleteById(id);
        
    }
    public UserModel getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        return userService.findByUserName(username);
    }
    
}
