package com.example.todo_backend.controller;

// ONLY FOR ADMINS

import com.example.todo_backend.model.UserModel;
import com.example.todo_backend.service.UserService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService user;

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users")
    public ResponseEntity<List<UserModel>> getAllusers(){
        return new ResponseEntity<>(user.getAlluser(), HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/users")
    public ResponseEntity<Object> addUser(@RequestBody UserModel usermodel){
        return new ResponseEntity<>(user.addUser(usermodel),HttpStatus.CREATED);
    }
}
