package com.example.todo_backend.service;


import com.example.todo_backend.model.UserModel;
import com.example.todo_backend.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepo users;

    public Optional<UserModel> loadUserByUsername(String username) throws UsernameNotFoundException{
        return  users.findByUserName(username);
    }

    public UserModel findByUserName(String username) {
        return users.findByUserName(username).orElse(null);
    }

    public List<UserModel> getAlluser() {
        return users.findAll();
    }

    public Object addUser(UserModel usermodel) {
        return users.save(usermodel);
    }

    public String create(String username,String Password){
        UserModel user= (UserModel) User.builder().username(username).password(new BCryptPasswordEncoder().encode(Password)).authorities("MEMBERS").build();
        users.save(user);
        return "Create Successfully";
    }

    public void saveUser(UserModel user) {
        users.save(user);
    }

    public boolean existsByUsername(String username) {
        return users.existsByUserName(username);
    }

    public UserModel registerUser(UserModel user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        return users.save(user);
    }
}
