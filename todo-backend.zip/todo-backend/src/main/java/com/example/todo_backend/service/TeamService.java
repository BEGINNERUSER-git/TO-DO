package com.example.todo_backend.service;

import com.example.todo_backend.model.CreateTeam;
import com.example.todo_backend.model.TeamModel;
import com.example.todo_backend.model.UserModel;
import com.example.todo_backend.repository.TeamRepo;
import com.example.todo_backend.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ControllerAdvice;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@ControllerAdvice
public class TeamService {

    @Autowired
    private TeamRepo teamRepo;

    @Autowired
    private UserRepo userRepo;


    public List<TeamModel> getAllTeams() {
        return teamRepo.findAll();
    }

    public Object createTeam(CreateTeam createteam) {
        TeamModel team=new TeamModel();
        team.setTeamName(createteam.getTeamName());
        team.setTeamDescription(createteam.getTeamDescription());
        team.setDueDate(createteam.getDueDate());
        Set<UserModel> members=new HashSet<>(userRepo.findAllById(createteam.getMembersIds()));
        team.setMembers(members);
        return teamRepo.save(team);
    }
}
