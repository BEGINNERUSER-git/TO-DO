package com.example.todo_backend.repository;

import com.example.todo_backend.model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.Optional;

public interface UserRepo extends JpaRepository<UserModel,Integer> {

    Optional<UserModel> findByUserName(String username);
    boolean existsByUserName(String username);
}
